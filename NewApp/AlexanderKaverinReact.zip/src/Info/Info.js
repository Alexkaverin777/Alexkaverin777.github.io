import React from 'react';

const Info = () =>{
	return (
		<div className="bloc-info">
			<p className="info">
				Я в скорем времения стану front end developer
			</p>
			<p className="info">
				В данный момент в городе Киев карантин остался без работу. Изучаю с Вашей командо front end
			</p>
		</div>

	)
};

export default Info;
