import React from 'react';
import Info from "../Info/Info";

const Body = () => {
	return (
		<section className="info-user">
			<Info/>
		</section>
	)

};

export default Body
